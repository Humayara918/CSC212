#include "sequence1.h"
#include <iostream>
using namespace std;

//typedef int value_type; //data type in the sequence
//typedef std::size_t size_type; //std::size_t can store the maximum size of a theoretically possible object
//size_type is the data type of any variable that keeps track of how many items are in a sequence

namespace main_savitch_3 {
    const sequence::size_type sequence::CAPACITY;
     sequence::sequence(){
           m_used=0; //since we are initializing as an empty sequence there will be "zero" data being used
           //m_data= new sequence::value_type[m_capacity]; //m_capacity represents what the initial capacity is
           m_current_index= m_capacity -1; // Index starts with zero so we -1
           m_size=0;
           m_current=NULL;
     }
     void sequence::start() {
        if (m_size != 0) {
            m_current= m_data[0]; // first value in array
            m_current_index = 0;
        }
        else {
            m_current = NULL;
        }
     }
     void sequence::advance(){
         if (is_item()) {
             
            if (m_current == m_data[m_size - 1]) {
                m_current = NULL;//no current
            }
            else {
                m_current_index++;
                m_current = m_data[m_current_index]; //new current item is the item after the orginal current item
        
            }
         }
     }
      void sequence::insert(const value_type& entry){
                if (size()<CAPACITY){
                    cout << (m_current != NULL);
                    cout << "Here I am\n";
                    if (m_current != NULL){
                        cout << size()<< endl;
                        for(int index1 = size(); index1 > (m_current_index - 1); index1--) {
                            cout << "Here I go!"<< endl;
                            if (index1 != m_current_index) {
                                m_data[index1] = m_data[index1 - 1];
                            }
                            else {
                                m_data[index1]= entry; //the new value inserted is at current index
                                //m_data[m_current_index +1] = m_current; // the vlaue that was before is now set after the entry 
                            }
                        }
                    } 
                    else{
                        cout << "Huma" <<endl;
                        for(int index = m_size; index > -1; index--) {
                            if (index != 0) {
                                m_data[index] = m_data[index - 1];
                            }
                            else {
                                m_data[index]= entry; //the new value inserted is at current index
                                //wm_data[m_current_index +1] = m_current; // the vlaue that was before is now set after the entry 
                                m_current_index = 0;
                            }
                        }
                        /*m_data[0]= entry;
                        m_current_index= 0; //entry is gpoing tp be the front of the sequence*/
                    } 
                    m_current= entry; 
                    m_size++;
                }
    }
    void sequence::attach(const value_type& entry) {
        if (m_current != NULL){
            if (m_current_index == m_size - 1) {
                m_data[m_current_index +1]= entry;
                m_current_index++;
            }
            else {
                for (int index = m_size; index > m_current_index; index--) {
                    if(index == m_current_index + 1) {        
                        m_data[m_current_index +1]= entry;
                        m_current_index++;
                    }
                    else {
                        m_data[index] = m_data[index - 1];
                    }
                }
            }
        }
        else{
            m_data[0]= entry;
            cout << "I am here!\n";
            m_current_index=0;
        }
        m_current= entry;
        m_size++;
    }
                
                // a[0] = 1;
                // a[1] = 2;
                // size < CAPACITY
                // [1, 2, 4] = m_data sequence. insert(10 = entry). 4 is the current value. current index is 2. [1, 2, 10, 4]
                // insert 10 before 4
                // current value is NULL:
                // insert 10 before 1

                // current value is 10.

                void sequence::remove_current(){
                        if(is_item()){
                             for (sequence::size_type i=m_current_index; i<m_used; i++) {
                                 m_data[i]=m_data[i+1];
                             }
                             m_used--;
                        }
                }
                sequence::size_type sequence::size() const {
                    return m_size;
                }
                bool sequence::is_item() const{
                    return m_current != NULL;
                }
                sequence::value_type sequence::current() const{
                    return m_data[m_current_index];
                }
         }
     

